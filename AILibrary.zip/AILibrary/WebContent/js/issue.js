var inputbookid = document.getElementById('bookid');
var inputstdid = document.getElementById('stdid');

function issue(){
	  bookid = inputbookid.value;
	  stdid = inputstdid.value;
	  var y = stdid.slice(0,3);
	  console.log(y);
	  var tmp1 = 0;

	  var ref = firebase.database().ref("Books/" + bookid + "/");
		ref.once("value")
		  .then(function(snapshot) {
		    var a = snapshot.child("BookID").exists(); // true
		    
		    if(a == true){
		    	var ref = firebase.database().ref("Books/" + bookid + "/");
		   	 		ref.once("value")
		   	   .then(function(snapshot) {
		   	     var key = snapshot.key;
		   	     var childKey = snapshot.child("BookID/").key;
		   	     var status = snapshot.child("Status/").val();
		   	     console.log(status);
		    	if(status == "Available"){
		    		tmp1 = 1;
		    	}
		    	nextFun(tmp1, y);
		    	});	    
		   	 }
		  });
}
function nextFun(x, stdType){
	var tmp = 0;
	  
	  if(stdType == "STD"){
		  var ref = firebase.database().ref("Students/" + stdid + "/");
			ref.once("value")
			  .then(function(snapshot) {
				  var b = snapshot.child("StudentID").exists(); // true
				  
				  if(b == true){
					  tmp = 1;
					 }
				  fun(tmp, x, stdType);
			  });
	  }
	  else if(stdType == "PRO"){
		  var ref = firebase.database().ref("Professors/" + stdid + "/");
			ref.once("value")
			  .then(function(snapshot) {
				  var b = snapshot.child("ProfessorID").exists(); // true
				 
				  if(b == true){
					  tmp = 1;
					 }
				  fun(tmp, x, stdType);
			  });
	  }	 
}

function fun(a, b, c){
	bookid = inputbookid.value;
	stdid = inputstdid.value;
	
	console.log(a,b,c);
	if(a == 1 && b == 1){ //insert records here
		try{
						
			if(c == "STD"){
				
						var issueNumber = "issue";
				    	var ref = firebase.database().ref("Students/" + stdid + "/");
			   	 		ref.once("value")
			   	   			.then(function(snapshot) {
			   	     			var key = snapshot.key;
			   	     			var childKey = snapshot.child("StudentID/").key;
			   	     			issueNumber = snapshot.child("BookIssued/").val();
			   	     			Pass = snapshot.child("Password/").val();
			   	     			
			   	     			console.log(issueNumber);
			   	     			
			   	     			
		   	     			if(issueNumber !=  "e" && Pass != "def123"){
		   	     				

			   	     			if(issueNumber == "xx"){
			   	     				issueNumber = "a";
			   	     			}else if(issueNumber == "a"){
			   	     				issueNumber = "b";
			   	     			}else if(issueNumber == "b"){
			   	     				issueNumber = "c";
			   	     			}else if(issueNumber == "c"){
			   	     				issueNumber = "d";
			   	     			}else if(issueNumber == "d"){
			   	     				issueNumber = "e";
			   	     			}
		   	     				
			   	     				//issueNumber++;
			   	     			console.log(issueNumber);
			   	     			
			   	     		firebase.database().ref("Issued/" + bookid).set({
			   		    	    BookID: bookid,
			   		    	    StudentID: stdid
			   		    	  });
			   	     		
			   	     		
			   	     firebase.database().ref("IssuedTo/" + stdid + "/" + bookid).update({
		   	     			BookID: bookid
		   	     		});
			   	     		
			   				
			   				var adaNameRef = firebase.database().ref('Books/' + bookid);
			   				adaNameRef.update({ Status: "Issued to " + stdid });


			   	     		var adaNameRef = firebase.database().ref('Students/' + stdid);
			   	     		adaNameRef.update({ BookIssued: issueNumber });
			   	     				

			   	   	    	  document.getElementById("errmsg").innerHTML = "Book Issed";
			   	   	    	  document.getElementById("errmsg").style.display='block';
			   	   	    	  document.getElementById("issueform").reset();
			   	     			}
			   	     			else{
			   	     				document.getElementById("errmsg").innerHTML = "Issued Limit Excedded or student is not allowed";
			   	     				document.getElementById("errmsg").style.display='block';
			   	     				document.getElementById("issueform").reset();
			   	     			}			   	     			
			   	   			});
				
			
			}
			
			else if(c == "PRO"){
				
				var issueNumber = 0;
		    	var ref = firebase.database().ref("Professors/" + stdid + "/");
	   	 		ref.once("value")
	   	   			.then(function(snapshot) {
	   	     			var key = snapshot.key;
	   	     			var childKey = snapshot.child("ProfessorID/").key;
	   	     			issueNumber = snapshot.child("BookIssued/").val();
	   	     			Pass = snapshot.child("Password/").val();
	   	     			
	   	     			console.log(issueNumber);
	   	     		if(issueNumber !=  "e" && Pass != "def123"){
   	     				

	   	     			if(issueNumber == "xx"){
	   	     				issueNumber = "a";
	   	     			}else if(issueNumber == "a"){
	   	     				issueNumber = "b";
	   	     			}else if(issueNumber == "b"){
	   	     				issueNumber = "c";
	   	     			}else if(issueNumber == "c"){
	   	     				issueNumber = "d";
	   	     			}else if(issueNumber == "d"){
	   	     				issueNumber = "e";
	   	     			}
	   	     			console.log(issueNumber);
	   	     			
	   	     		firebase.database().ref("Issued/" + bookid).set({
	   		    	    BookID: bookid,
	   		    	    StudentID: stdid
	   		    	  });
	   	     		
	   				var adaNameRef = firebase.database().ref('Books/' + bookid);
	   				adaNameRef.update({ Status: "Issued to " + stdid });


	   	     		var adaNameRef = firebase.database().ref('Professors/' + stdid);
	   	     		adaNameRef.update({ BookIssued: issueNumber});
	   	     		
	   	         	  document.getElementById("errmsg").innerHTML = "Book Issed";
	   	   	    	  document.getElementById("errmsg").style.display='block';
	   	   	    	  document.getElementById("issueform").reset();
	   	     			}
	   	     			else{
	   	     				document.getElementById("errmsg").innerHTML = "Issued Limit Excedded or professor is not allowed";
	   	     				document.getElementById("errmsg").style.display='block';
	   	     				document.getElementById("issueform").reset();
	   	     			}			   	     			
	   	   			});
				
				
			}
			
			
		}
		catch(err){
			console.log(err);
			document.getElementById("errmsg").innerHTML = "Something went wrong, please try again!!";
			document.getElementById("errmsg").style.display='block';
	    	document.getElementById("issueform").reset();
		}
	}
	else if(a == 0 && b == 1){
		document.getElementById("errmsg").innerHTML = "Student record not found";
		document.getElementById("errmsg").style.display='block';
  	  	document.getElementById("issueform").reset();
	}
	else if(a == 1 && b == 0){
		document.getElementById("errmsg").innerHTML = "Book record not found or Issued to someone";
		document.getElementById("errmsg").style.display='block';
  	  	document.getElementById("issueform").reset();
	}
	else if(a == 0 && b == 0){
		document.getElementById("errmsg").innerHTML = "Book and Student record not found";
		document.getElementById("errmsg").style.display='block';
  	  	document.getElementById("issueform").reset();
	}
}
