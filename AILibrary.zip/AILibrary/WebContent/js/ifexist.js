var inputbook = document.getElementById("bookid");
var inputstd = document.getElementById("stdid");
function ifexist(){
	var book = inputbook.value;
	var std = inputstd.value;
	var ref = firebase.database().ref("Books/" + book + "/");
	ref.once("value")
	  .then(function(snapshot) {
	    var a = snapshot.exists();  // true
	    var b = snapshot.child("Title").exists(); // true
	    if (b == true){
			console.log("exist");
		}
		else{
			console.log("Not exist");
		}
	  });
}