var inputbookidno = document.getElementById('subid');

function submitform(){
	  bookidno = inputbookidno.value;
	  
	  try{
	  // finding student id
		  
			var ref = firebase.database().ref("Issued/" + bookidno + "/");
 			ref.once("value")
 				.then(function(snapshot) {
 					var key = snapshot.key;
 					var avl = snapshot.child("BookID").exists(); // true
 					var childKey = snapshot.child("BookID/").key;
 					var bookIDfromDB = snapshot.child("BookID/").val();
	     			var issuesrdid = snapshot.child("StudentID/").val();
	     			
	     			console.log(bookIDfromDB, issuesrdid);
		  
		  if(avl == true){
	     		    console.log("avt true");
	     // finding book issued
	     			slicestdIssue = issuesrdid.slice(0,3);
	     			var issueNumbers = "o";
	     			
	     			if(slicestdIssue == "STD"){
	     				var ref = firebase.database().ref("Students/" + issuesrdid + "/");
		    	 		ref.once("value")
		    	   			.then(function(snapshot) {
		    	     			var key = snapshot.key;
		    	     			var childKey = snapshot.child("StudentID/").key;
		    	     			issueNumbers = snapshot.child("BookIssued/").val();
		    	     			
		    	     			if(issueNumbers == "a" || issueNumbers == "b" || issueNumbers == "c" || issueNumbers == "d" || issueNumbers == "e"){
		    	     				var adaRef = firebase.database().ref("Issued/" + bookidno);
	     							adaRef.remove()
	     								.then(function() {
	     									console.log("Remove succeeded.")
	     									
	     									
	     										var adaReff = firebase.database().ref("IssuedTo/"+ issuesrdid + "/" + bookidno);
	     											adaReff.remove()
	     											  .then(function() {
	     													console.log("Remove succeeded22.")
	     									
	     									
	     									var adaNameRef = firebase.database().ref('Books/' + bookidno);
	     									adaNameRef.update({ Status: "Available" });
	     									
	     									if(issueNumbers == "b"){
	     				   	     				issueNumbers = "a";
	     				   	     			}else if(issueNumbers == "c"){
	     				   	     				issueNumbers = "b";
	     				   	     			}else if(issueNumbers == "d"){
	     				   	     				issueNumbers = "c";
	     				   	     			}else if(issueNumbers == "e"){
	     				   	     				issueNumbers = "d";
	     				   	     			}else if(issueNumbers == "a"){
	     				   	     				issueNumbers = "xx";
	     				   	     			}
	     									
	     									var adaNameRef = firebase.database().ref('Students/' + issuesrdid);
	     									adaNameRef.update({ BookIssued: issueNumbers });
						
						document.getElementById("errmsgs").innerHTML = "Book submitted successfuly";
						document.getElementById("errmsgs").style.display='block';
				  	  	document.getElementById("submitforms").reset();
				    });
	     								});
		    	     			}
		    	     			
		    	   			});
	     			}
	     			else if(slicestdIssue == "PRO"){
	     				var ref = firebase.database().ref("Professors/" + issuesrdid + "/");
		    	 		ref.once("value")
		    	   			.then(function(snapshot) {
		    	     			var key = snapshot.key;
		    	     			var childKey = snapshot.child("ProfessorID/").key;
		    	     			issueNumbers = snapshot.child("BookIssued/").val();
		    	     			
		    	     			if(issueNumbers == "a" || issueNumbers == "b" || issueNumbers == "c" || issueNumbers == "d" || issueNumbers == "e"){
		    	     				var adaRef = firebase.database().ref("Issued/" + bookidno);
	     							adaRef.remove()
	     								.then(function() {
	     									console.log("Remove succeeded.")
	     									
	     									var adaNameRef = firebase.database().ref('Books/' + bookidno);
	     									adaNameRef.update({ Status: "Available" });
	     									
	     									if(issueNumber == "b"){
	     				   	     				issueNumber = "a";
	     				   	     			}else if(issueNumber == "c"){
	     				   	     				issueNumber = "b";
	     				   	     			}else if(issueNumber == "d"){
	     				   	     				issueNumber = "c";
	     				   	     			}else if(issueNumber == "e"){
	     				   	     				issueNumber = "d";
	     				   	     			}else if(issueNumber == "a"){
	     				   	     				issueNumber = "xx";
	     				   	     			}
	     									
	     									var adaNameRef = firebase.database().ref('Professors/' + issuesrdid);
	     									adaNameRef.update({ BookIssued: issueNumbers });
						
						document.getElementById("errmsgs").innerHTML = "Book submitted successfuly";
						document.getElementById("errmsgs").style.display='block';
				  	  	document.getElementById("submitforms").reset();
				    });
		    	     			}
		    	   			});
	     			}
	     		
	  }
		  else{
			  console.log("Remove failed: ")
		      document.getElementById("errmsgs").innerHTML = "Record not found";
			  document.getElementById("errmsgs").style.display='block';
		  	  document.getElementById("submitforms").reset();
		  }
 				});
	  }
	  catch(err){
		  console.log(err);
	  }
}