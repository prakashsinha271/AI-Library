var inputUname = document.getElementById('uname');
var inputPass = document.getElementById('psw');



function loginjs(){
	//console.log("function called");
	inUname = inputUname.value;
	inPass = inputPass.value;
	
	var ref = firebase.database().ref("Administrator/");
	 ref.once("value")
	   .then(function(snapshot) {
	     var key = snapshot.key;
	     var childKey = snapshot.child("LogID/").key;
	     var dbUName = snapshot.child("LogID/").val();
	     var dbUPass = snapshot.child("Password/").val();
	     if(dbUName == inUname && dbUPass == inPass){
	    	 window.location.href = "home.jsp";
	     }
	     else{
	    	 window.alert("Incorrect Credential!!");
	    	 window.location.href = "index.jsp";
	     }
	   });
}