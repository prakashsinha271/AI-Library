var firebaseConfig = {
    apiKey: "AIzaSyC4uTyXU5_TIrP71iwRCnHzC2XwEXkRkXo",
    authDomain: "aildb-2106a.firebaseapp.com",
    databaseURL: "https://aildb-2106a.firebaseio.com",
    projectId: "aildb-2106a",
    storageBucket: "aildb-2106a.appspot.com",
    messagingSenderId: "852753636472",
    appId: "1:852753636472:web:586494e65ae7c8d7ade18d",
    measurementId: "G-0C10EZ6FXF"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();
